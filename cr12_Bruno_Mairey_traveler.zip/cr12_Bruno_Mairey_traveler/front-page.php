<?php get_header(); ?>
  

<main>
  
  <div id="frontpage">
   <img class="img-fluid" style="background-size: cover;" src="<?php echo get_template_directory_uri(); ?>/img/front.jpg" alt="image">  
     <div id ="buttonmiddle">
     	<a href="blog"><button id="enterbutton" type="button" class="btn btn-info btn-lg">Read our blog</button></a>
    
</div>
</div>
 
</main>



 <?php get_footer(); ?>


