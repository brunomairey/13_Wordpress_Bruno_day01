 <?php wp_footer(); ?>

<footer>

  <div class="p-5" style="background-color: #2262A9; width: 100%; text-align: center">
            <span style="color: white; font-size: 3vw;">
                <?php bloginfo('name'); ?> written by <?php the_author(); ?> </span><br><br>
      <div style="display: flex; justify-content: center">
   <?php
      if(is_active_sidebar('sidebar')):
     dynamic_sidebar($footer);
     endif;  

     // I had here issue at the beginning by a fix name. That is why I input a variable in order to reload - when you will open it. 
     // In case it is not working by the import for you, please just change the name in the variable of the function file and in this file inside the dynamic footer and it will magicaly work. 

     // We recommend the use of the social media widget (to be installed with a plugin). However due to our big pading (p-5) every element will insert perfectly in the footer of our website.
?>
  
    </div>
</div>

     
</footer>

</html>

<script type="text/javascript">
    //var images = document.getElementsByTagName("img");
    var images = document.getElementsByClassName("wp-post-image");
    
  var i;

  for(i = 0; i < images.length; i++) {
    images[i].className += " card-img-top imageheight";
}


    // $("img").addClass("card-img-top");
   </script>


</body>
</html>